package tests;
import ecgParser.Parser;

public class Test {

	public static void main(String[] args) {
		Parser.readFile("/Users/antonia/Desktop/Informática 4º Curso/Repos/DSINT/ECG-input3.1/bradicardia.ecg.fix");
	}
}
