package domain;

public enum WaveType {
	
	P, Q, R, S, T;

}
